package com.example.m0815037;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorEventListener2;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import java.util.List;

public class MainActivity extends AppCompatActivity implements SensorEventListener {
    SensorManager mSensorManager;

    Sensor accelerometer;
    Sensor magnetometer;

    TextView tvAzimuth, tvPitch, tvRoll;

    float[] accelerometerReading;
    float[] magnetometerReading;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvAzimuth = findViewById(R.id.tv_azimuth);
        tvPitch = findViewById(R.id.tv_pitch);
        tvRoll = findViewById(R.id.tv_roll);

        mSensorManager = (SensorManager) getSystemService(
                Context.SENSOR_SERVICE);

        this.accelerometer = this.mSensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        this.magnetometer = this.mSensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);


        List<Sensor> sensorList  =
                mSensorManager.getSensorList(Sensor.TYPE_ALL);
//        this.showAllSensor();





    }

    public void showAllSensor(){
        List<Sensor> sensorList = this.mSensorManager.getSensorList(Sensor.TYPE_ALL);

        for(Sensor currentSensor : sensorList){
            Log.d("sensor", currentSensor.getName());
        }
    }

    @Override
    protected void onStart(){
        super.onStart();
        if(this.accelerometer != null){
            this.mSensorManager.registerListener(this, this.accelerometer, SensorManager.SENSOR_DELAY_NORMAL);
        }
        if(this.magnetometer != null){
            this.mSensorManager.registerListener(this, this.magnetometer, SensorManager.SENSOR_DELAY_NORMAL);
        }
    }

    @Override
    protected  void onStop(){
        super.onStop();
        this.mSensorManager.unregisterListener(this);
    }


    @Override
    public void onSensorChanged(SensorEvent event){
        int sensorType = event.sensor.getType();
        switch (sensorType) {
            case Sensor.TYPE_ACCELEROMETER:
                this.accelerometerReading = event.values.clone();
                final float[] rotationMatrix = new float[9];
                mSensorManager.getRotationMatrix(rotationMatrix, null, accelerometerReading, magnetometerReading);
                // Express updated rotation matrix as 3 orientation angles.
                final float[] orientationAngles = new float[3];
                mSensorManager.getOrientation(rotationMatrix, orientationAngles);
                tvAzimuth.setText("Azimuth : "+orientationAngles[0]);
                tvPitch.setText("Pitch: "+orientationAngles[1]);
                tvRoll.setText("Roll : "+orientationAngles[2]);
                break;

            case Sensor.TYPE_MAGNETIC_FIELD:
                this.magnetometerReading = event.values.clone();
                break;
        }
        // Rotation matrix based on current readings.



    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {

    }

}
