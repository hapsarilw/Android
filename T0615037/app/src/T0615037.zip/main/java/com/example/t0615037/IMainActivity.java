package com.example.t0615037;

interface IMainActivity {

}
