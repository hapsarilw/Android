package com.example.t0215037;

import java.util.List;

public class MainPresenter {
    protected List<Food> foods;
}
