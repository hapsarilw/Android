package com.example.t0315037;

public interface FragmentListener {
    void changePage(int page);

    void setText();

    void closeApplication();
}
