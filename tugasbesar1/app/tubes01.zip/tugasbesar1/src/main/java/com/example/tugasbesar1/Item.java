package com.example.tugasbesar1;

public class Item {
//    protected String operator;
    protected String number;

    public Item(String number) {
//        this.operator = operator;
        this.number = number;
    }

//    public String getOperator() {
//        return this.operator;
//    }
//
//    public void setOperator(String operator) {
//        this.operator = operator;
//    }



    public String getNumber() {
        return this.number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

}
