package com.example.tubes3.model;

import java.util.ArrayList;


public class ImageModel  {
    ArrayList<ArrayList<Object>> images;
    public ImageModel(){

    }

    public ArrayList<ArrayList<Object>> getImages() {
        return images;
    }

    public void setImages(ArrayList<ArrayList<Object>> images) {
        this.images = images;
    }
}
