package com.example.tubes3.model;

import java.util.ArrayList;


public class Mangalist {
    String a;   //alias
    ArrayList<String> c;    //category
    String h;   //hits
    String i;   //id
    String im;  //img url
    String ld;  //last date
    String s;   //status
    String t;   // title
    public Mangalist(){

    }
    public ArrayList<String> getC() {
        return c;
    }


    public String getI() {
        return i;
    }
    public String getIm() {
        return im;
    }


    public String getT() {
        return t;
    }

}
