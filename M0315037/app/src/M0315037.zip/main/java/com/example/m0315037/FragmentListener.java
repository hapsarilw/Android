package com.example.m0315037;

public interface FragmentListener {
    void changePage(int page);

    void changeMessage(String message);
}
